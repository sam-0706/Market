# Market-Place
ecommerce platform created on flask and mysql
